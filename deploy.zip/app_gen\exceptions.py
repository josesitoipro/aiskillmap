class FailedDependencyException(Exception):
    pass