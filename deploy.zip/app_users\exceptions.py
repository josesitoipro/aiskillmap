class InvalidCredentialsException(Exception):
    pass

class InactiveUserException(Exception):
    pass

class ProtectedUserException(Exception):
    pass